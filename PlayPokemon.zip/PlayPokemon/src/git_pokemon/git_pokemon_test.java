package git_pokemon;

public class git_pokemon_test {
	  public static void main(String[] args) {
		  System.out.println("git test");
	  }

}
